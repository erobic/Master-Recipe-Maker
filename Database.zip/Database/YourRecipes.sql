-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 23, 2012 at 03:03 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `YourRecipes`
--

-- --------------------------------------------------------

--
-- Table structure for table `edge`
--

CREATE TABLE IF NOT EXISTS `edge` (
  `from` int(11) NOT NULL,
  `to` int(11) NOT NULL,
  `weight` double NOT NULL,
  PRIMARY KEY (`from`,`to`),
  KEY `from` (`from`,`to`),
  KEY `from_node` (`from`,`to`),
  KEY `to` (`to`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `edge`
--

INSERT INTO `edge` (`from`, `to`, `weight`) VALUES
(1, 28, 10),
(1, 38, 10),
(1, 43, 160),
(1, 47, 40),
(28, 29, 10),
(29, 30, 10),
(30, 31, 10),
(31, 2, 10),
(31, 32, 10),
(32, 33, 10),
(33, 34, 10),
(34, 35, 10),
(35, 36, 10),
(36, 37, 10),
(36, 39, 10),
(37, 31, 10),
(38, 36, 10),
(39, 40, 10),
(40, 41, 10),
(41, 42, 10),
(42, 2, 10),
(43, 44, 130),
(43, 45, 20),
(43, 46, 10),
(44, 2, 60),
(44, 45, 120),
(44, 46, 20),
(45, 2, 120),
(45, 44, 30),
(46, 2, 20),
(46, 44, 20),
(47, 48, 40),
(48, 49, 40),
(49, 44, 20),
(49, 45, 10),
(49, 46, 10);

-- --------------------------------------------------------

--
-- Table structure for table `node`
--

CREATE TABLE IF NOT EXISTS `node` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `method` varchar(50) DEFAULT NULL,
  `noun` varchar(50) DEFAULT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `quantity` double DEFAULT NULL,
  `standard_deviation` double DEFAULT NULL,
  `frequency` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unit` (`unit`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=50 ;

--
-- Dumping data for table `node`
--

INSERT INTO `node` (`id`, `method`, `noun`, `unit`, `quantity`, `standard_deviation`, `frequency`) VALUES
(1, 'start', 'recipe', NULL, NULL, NULL, NULL),
(2, 'finish', 'recipe', NULL, NULL, NULL, NULL),
(28, 'Peel', 'potatoes', 'none', 0, 0, 1),
(29, 'Cut', 'them', 'none', 0, 0, 1),
(30, 'Boil', 'water', 'none', 0, 0, 1),
(31, 'Add', 'salt', 'none', 0, 0, 2),
(32, 'Cook', 'potatoes', 'none', 0, 0, 1),
(33, 'Drain', 'potatoes', 'none', 0, 0, 1),
(34, 'Heat', 'saucepan', 'none', 0, 0, 1),
(35, 'Shake', 'saucepan', 'none', 0, 0, 1),
(36, 'Mash', 'potatoes', 'none', 0, 0, 2),
(37, 'Add', 'butter', 'none', 0, 0, 1),
(38, 'Boil', 'potatoes', 'none', 0, 0, 1),
(39, 'Heat', 'cream', 'none', 0, 0, 1),
(40, 'Heat', 'butter', 'none', 0, 0, 1),
(41, 'Beat', 'potatoes', 'none', 0, 0, 1),
(42, 'Press', 'potatoes', 'none', 0, 0, 1),
(43, 'Boil', 'water', 'cup', 2.6666666666667, 0.2087377028029, 7),
(44, 'Add', 'sugar', 'teaspoon', 1.6, 0.17504216426539, 11),
(45, 'Add', 'tea', 'teaspoon', 1.6666666666667, 0.23094010767584, 6),
(46, 'Add', 'coffee', 'teaspoon', 1.5, 0.27638539919628, 4),
(47, 'Pour', 'milk', 'cup', 1, 0, 4),
(48, 'Add', 'water', 'cup', 1, 0, 4),
(49, 'Boil', 'milk', 'none', 0, 0, 4);

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE IF NOT EXISTS `unit` (
  `unit` varchar(50) NOT NULL,
  PRIMARY KEY (`unit`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`unit`) VALUES
('cup'),
('gram'),
('litre'),
('millilitre'),
('none'),
('pound'),
('tablespoon'),
('teaspoon'),
('units');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `edge`
--
ALTER TABLE `edge`
  ADD CONSTRAINT `edge_ibfk_1` FOREIGN KEY (`from`) REFERENCES `node` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `edge_ibfk_2` FOREIGN KEY (`to`) REFERENCES `node` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `node`
--
ALTER TABLE `node`
  ADD CONSTRAINT `node_ibfk_1` FOREIGN KEY (`unit`) REFERENCES `unit` (`unit`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
