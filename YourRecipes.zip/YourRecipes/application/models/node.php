<?php

/*
 * Each node has an id, method, noun, mean quantity, unit, standard_deviation of the mean quantity,
 * and the frequency (number of times it took part in a training).
 */

class Node extends CI_Model {

    var $id = null, $method = null, $noun = null, $unit = 'none', $quantity = 0, $standard_deviation = 0, $frequency = 1;
    protected $old_mean = 0, $old_standard_deviation = 0, $old_frequency = 0;
    protected $table = 'node';

    function __construct() {
        parent::__construct();
    }

    //////////UTITLITIES//////////
    /* It converts from one unit to another. i.e. pound to gram, tablespoon to teaspoon, litre to millilitre. */

    public function convert_units() {
        if (strcmp($this->unit, 'pound') == 0) {
            $this->quantity*=453.59;
            $this->unit = 'gram';
        } else if (strcmp($this->unit, 'tablespoon') == 0) {
            $this->quantity*=3;
            $this->unit = 'teaspoon';
        } else if (strcmp($this->unit, 'litre') == 0) {
            $this->quantity*=1000;
            $this->unit = 'millilitre';
        }
    }

    /* It calculates new frequency, mean and standard deviation if the current node has a finite quantity. */

    public function calculate_new_parameters() {

        if (isset($this->quantity)) {
            $this->frequency = $this->old_frequency + 1;

            $this->quantity = ($this->old_mean * $this->old_frequency + $this->quantity) / $this->frequency;

            $this->standard_deviation = (pow($this->old_standard_deviation, 2) * $this->old_frequency);
            $this->standard_deviation += pow($this->quantity - $this->old_mean, 2);

            $this->standard_deviation = sqrt($this->standard_deviation / $this->frequency);
        }
    }

    /* It takes in an array with the field 
     * names same as the object and assigns the values to this object */

    public function assign_array($array) {
        if (!empty($array)) {
            if (isset($array["id"]))
                $this->id = $array["id"];

            if (isset($array["method"]))
                $this->method = $array["method"];

            if (isset($array["noun"]))
                $this->noun = $array["noun"];

            if (isset($array["unit"]))
                $this->unit = $array["unit"];

            if (isset($array["quantity"]))
                $this->quantity = $array["quantity"];

            if (isset($array["standard_deviation"]))
                $this->standard_deviation = $array["standard_deviation"];

            if (isset($array["frequency"]))
                $this->frequency = $array["frequency"];
        }
    }

    //////////END OF UTITLITIES//////////
    //////////DATA ACCESS FUNCTIONS//////////
    public function insert() {
        $this->db->insert($this->table, $this);
    }

    public function update() {
        $this->db->where('id', $this->id);
       $this->db->update($this->table, $this);
    }

    /* Assigns the $this object with the values from database */

    public function set_by_id() {
        $query = $this->db->get_where($this->table, array('id' => $this->id));
        $array = $query->result();
        if (isset($array)) {
            if (!empty($array)) {
                $this->method = $array[0]->method;
                $this->noun = $array[0]->noun;
                $this->unit = $array[0]->unit;
                $this->quantity = $array[0]->quantity;
                $this->standard_deviation = $array[0]->standard_deviation;
                $this->frequency = $array[0]->frequency;
            }
        }
    }

    /*It sets the "old values" of mean, standard deviation and frequency.*/
    public function select_old_by_id() {
        $query = $this->db->get_where($this->table, array('id' => $this->id));
        $array = $query->result();
        if (isset($array)) {
            if (!empty($array)) {
                $this->old_mean = $array[0]->quantity;
                $this->old_standard_deviation = $array[0]->standard_deviation;
                $this->old_frequency = $array[0]->frequency;
            }
        }
    }

    /* It returns an array of nodes from an array of objects by retrieving
     * the required fields from the input objects
     */

    public function get_casted_nodes($objects) {
        if (isset($objects)) {
            $nodes = array();
            foreach ($objects as $object) {
                $node = new Node();
                if (isset($object->id))
                    $node->set_id($object->id);
                if (isset($object->noun))
                    $node->set_noun($object->noun);
                if (isset($object->method))
                    $node->set_method($object->method);
                if (isset($object->unit))
                    $node->set_unit($object->unit);
                if (isset($object->quantity))
                    $node->set_quantity($object->quantity);
                if (isset($object->standard_deviation))
                    $node->set_standard_deviation($object->standard_deviation);
                if (isset($object->frequency))
                    $node->set_frequency($object->frequency);
                $nodes[] = $node;
            }
            return $nodes;
        }
        return false;
    }

    /* Returns an array of nodes if they contain the same noun as $this node. */

    public function select_by_noun() {
        $query = $this->db->get_where($this->table, array('noun' => $this->noun));
        return $query->result();
    }

    /* It sets the id of this node if it already exists and return true.
     * Otherwise, it returns false. */

    public function set_id_if_exists() {
        $query = $this->db->get_where($this->table, array(
            'noun' => $this->noun,
            'method' => $this->method,
            'unit' => $this->unit
                ));
        $results = $query->result();
        if (!empty($results)) {
            $this->id = $results[0]->id;
            return true;
        }
        else
            $this->id = null;
        return false;
    }

    //////////END OF DATA ACCESS FUNCITONS//////////
    //////////SETTERS AND GETTERS//////////

    public function set_id($id) {
        $this->id = $id;
    }

    public function get_id() {
        return $this->id;
    }

    public function set_method($method) {
        /* @var $method type */
        $this->method = $method;
    }

    public function get_method() {
        return $this->method;
    }

    public function set_noun($noun) {
        $this->noun = $noun;
    }

    public function get_noun() {
        return $this->noun;
    }

    public function set_quantity($quantity) {
        $this->quantity = $quantity;
    }

    public function get_quantity() {
        return $this->quantity;
    }

    public function set_unit($unit) {
        $this->unit = $unit;
    }

    public function get_unit() {
        return $this->unit;
    }

    public function set_old_mean($old_mean) {
        $this->old_mean = $old_mean;
    }

    public function get_old_mean() {
        return $this->old_mean;
    }

    public function set_old_standard_deviation($old_standard_deviation) {
        $this->old_standard_deviation = $old_standard_deviation;
    }

    public function get_old_standard_deviation() {
        return $this->old_standard_deviation;
    }

    public function set_standard_deviation($standard_deviation) {
        $this->standard_deviation = $standard_deviation;
    }

    public function get_standard_deviation() {
        return $this->standard_deviation;
    }

    public function set_frequency($frequency) {
        $this->frequency = $frequency;
    }

    public function get_frequency() {
        return $this->frequency;
    }

    public function set_old_frequency($old_frequency) {
        $this->old_frequency = $old_frequency;
    }

    public function get_old_frequency() {
        return $this->old_frequency;
    }

    //////////END OF SETTERS AND GETTERS//////////
}

?>
