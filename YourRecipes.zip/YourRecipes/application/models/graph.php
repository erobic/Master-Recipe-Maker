<?php

/*
 * This class stores a graph in the form of a matrix of edges.
 * It can also store the same graph in the form of 2D matrix.
 * For example: 
 * Graph =  {(from,to,weight)}
 * OR
 * Graph[from][to] = weight
 */

class Graph extends CI_Model {
    /* $edges = array of edges
      $nodes = array of index=>node ids
      $matrix = matrix form of the graph
     * $width_matrix = width of the matrix
     */

    protected $edges, $nodes, $matrix, $width_matrix;
    protected $node_ids;
    protected $CI;

    public function __construct() {
        parent::__construct();
        $this->CI = & get_instance();
        $this->CI->load->model('node');
        $this->CI->load->model('edge');
    }

    //////////UTILITIES//////////

    /* It stores nouns to $nodes. Use it when the nouns are separated by commas.
     * For example: when the user specifies the list of ingredients, he/she
     * will provide comma-separated list of nouns.
     */
    public function set_nodes_from_nouns($noun_list) {
        if (isset($noun_list)) {
            $noun_list = str_replace(' ', '', $noun_list);
            $noun_array = explode(",", $noun_list);
            foreach ($noun_array as $noun) {
                $node = new Node();
                $node->set_noun($noun);
                $this->nodes[] = $node;
            }
        }
    }

    /* It constructs the array of nodes i.e. $nodes,
     * from the array of edges i.e. from $edges. */

    public function find_nodes_from_edges() {
        if (isset($this->edges)) {
            foreach ($this->edges as $edge) {
                $node = new Node();
                $node->set_id($edge->get_from());
                $node->set_by_id();
                $this->nodes[] = $node;
                if ($edge->get_to() == 2) {//if it is the "finish recipe" node
                    $node->set_id(2);
                    $node->set_by_id();
                    $this->nodes[] = $node;
                }
            }
            return true;
        }
        else
            return false;
    }

    /* It sets the ids of the nodes if the nouns exist, else it sets the id of
     * the node to null. It is to be noted there may be many nodes having the 
     * same noun. In that case, all the nodes are inserted into 
     * the $this->nodes.
     */

    public function set_ids_by_nouns() {
        if (isset($this->nodes)) {
            $temp_nodes = array();
            //For each node in the $nodes array, find out a list of nodes having
            //the same noun
            foreach ($this->nodes as $node) {
                $similar_objects = $node->select_by_noun();
                if (empty($similar_objects)) {//If such a noun does not exist, 
                    //then set id to null
                    $node->set_id(null);
                    array_merge($temp_nodes, array($node));
                } else {
                    $temp_node = new Node();
                    $similar_nodes = $temp_node->get_casted_nodes($similar_objects);
                    $temp_nodes = array_merge($temp_nodes, $similar_nodes);
                }
            }
            $this->nodes = $temp_nodes;
            return $this->nodes;
        }
        return false;
    }

    /* It adds the nodes "start recipe" and "finish recipe" to the array of nodes */

    public function store_start_finish_nodes() {
        $start_node = new Node();
        $start_node->set_id(1); //start node
        $end_node = new Node();
        $end_node->set_id(2); //finish node

        array_unshift($this->nodes, $start_node); //insert at the beginning of the array
        array_push($this->nodes, $end_node); //insert at the end of the array
    }

    /* It retrieves the id of a node (with noun, method and unit set) from the database, if 
     * the node exists. Then, it retrieves the old parameters and updates the node
     * with new parameters.
     * 
     * However, if the node is not present, then it inserts the node into the database and then
     * sets the id of the node.
     */

    public function insert_update_nodes() {
        foreach ($this->nodes as $node) {
            if ($node->get_id() != 1 && $node->get_id() != 2) {
                if ($node->set_id_if_exists()) {
                    $node->select_old_by_id();
                    $node->calculate_new_parameters();
                    $node->update();
                } else {
                    $node->insert();
                    $node->set_id_if_exists();
                }
            }
        }
    }

    /* It updates the edge with new parameter if the edge already exists.
     * However, if the edge does not exist, it just inserts it.
     */

    public function insert_update_edges() {
        if (isset($this->edges)) {
            foreach ($this->edges as $edge) {
                if ($edge->set_old_weight_if_exists()) {
                    $edge->calculate_new_weight();
                    $edge->update();
                } else {
                    $edge->insert();
                }
            }
        }
    }

    public function find_node_ids() {
        if (isset($this->nodes)) {
            foreach ($this->nodes as $node) {
                $this->node_ids[] = $node->get_id();
            }
        }
    }

    /* It converts a graph (array of edges) to a matrix form
     * such as: matrix[from_index][to_index] = weight
     * from_index and to_index are the indices of the nodes in the array $nodes
     * i.e. These are not the actual node ids.
     */

    public function graph_to_matrix() {
        foreach ($this->edges as $edge) {
            //Get the indices of the node ids from the array of nodes
            //Indices are singular i.e. each "indices" array has one index only
            $from_indices = array_keys($this->node_ids, $edge->get_from());
            $to_indices = array_keys($this->node_ids, $edge->get_to());

            if (!empty($from_indices) && !empty($to_indices)) {
                $from_index = $from_indices[0];
                $to_index = $to_indices[0];

                $this->matrix[$from_index][$to_index] = 10000 / ($edge->get_weight());

                $new_width = $from_index > $to_index ? $from_index : $to_index;
                $new_width++;
                if ($new_width > $this->width_matrix)
                    $this->width_matrix = $new_width;
            }
        }

        for ($i = 0; $i < $this->width_matrix; $i++) {
            $this->matrix[$i][$i] = 0;//a node is 0 distance away from itself.
        }
    }

    /* It stores all those edges inside $edges if the edges start and end
     * at nodes specified in the $this->nodes */

    public function find_edges_from_nodes() {
        $node_ids = array();
        foreach ($this->nodes as $node) {
            $node_ids[] = $node->get_id();
        }
        $temp_edge = new Edge();
        $this->edges = $temp_edge->select_edges_having_nodes($node_ids);
    }

    /* It nodes with null ids. */

    public function remove_nodes_with_null_ids() {
        if (isset($this->nodes)) {
            foreach ($this->nodes as $i => $node) {
                if ($node->get_id() == null) {
                    unset($this->nodes[$i]);
                }
            }
        }
    }

    //////////END OF UTITLITIES//////////
    //////////SETTERS AND GETTERS//////////

    public function set_edges($edges) {
        $this->edges = $edges;
    }

    public function get_edges() {
        return $this->edges;
    }

    public function set_nodes($nodes) {
        $this->nodes = $nodes;
    }

    public function get_nodes() {
        return $this->nodes;
    }

    public function set_matrix($matrix) {
        $this->matrix = $matrix;
    }

    public function get_matrix() {
        return $this->matrix;
    }

    public function set_width_matrix($width_matrix) {
        $this->width_matrix = $width_matrix;
    }

    public function get_width_matrix() {
        return $this->width_matrix;
    }

    public function set_node_ids($node_ids) {
        $this->node_ids = $node_ids;
    }

    public function get_node_ids() {
        return $this->node_ids;
    }

    //////////END OF SETTERS AND GETTERS//////////
}

?>
