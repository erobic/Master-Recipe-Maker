<?php

/*
 * A recipe is an array of nodes. 
 */

class Recipe extends CI_Model {

    protected $CI, $common_weight = 10;
    protected $graph;
    protected $noun_quantity_unit = null;
    ////This is the recipe in the form of a matrix.
    //The matrix contains node ids of the nodes.
    //There is a method to convert this 2D matrix into a $graph i.e. recipe    
    protected $matrix = null;

    function __construct() {
        parent::__construct();
        $this->CI = & get_instance();
        $this->CI->load->model('node');
        $this->CI->load->model('edge');
        $this->CI->load->model('graph');
    }

    //////////UTILITIES//////////

    /* It stores the recipe in the database. The recipe is an array of nodes.
     * If a node already exists i.e. if its id is already set, then, the old
     * parameters of the node are retrieved. Then, the new parameters are
     * calculated. Then, the node is updated.
     * 
     * Else, if a node does not exist, it is inserted
     *
     */

    public function store_recipe() {
        if (isset($this->graph)) {
            $this->graph->store_start_finish_nodes();
            $this->graph->insert_update_nodes();
            $this->construct_recipe();
            $this->graph->insert_update_edges();
        }
    }

    /* It constructs a recipe i.e. sets the array of edges with the given array of nodes. */

    public function construct_recipe($retrieve_weight_from_database = false) {
        if (isset($this->graph)) {
            $nodes = $this->graph->get_nodes();
            $edges = $this->graph->get_edges();
            for ($i = 0; $i < count($nodes) - 1; $i++) {
                $edge = new Edge();
                $edge->set_from($nodes[$i]->get_id());
                $edge->set_to($nodes[$i + 1]->get_id());
                if ($retrieve_weight_from_database == false) {
                    $edge->set_weight($this->common_weight);
                } else {

                    $edge->set_old_weight_if_exists(); //If the weight exists, then use it
                    //We do not need to calculate new weight. This is true when we are
                    //generating the recipe from the database
                    $edge->set_weight($edge->get_old_weight());
                }
                $edges[] = $edge;
            }
            $this->graph->set_edges($edges);
            return true;
        }
        return false;
    }

    /* The following function generates recipe from a 2D matrix */

    public function matrix_to_recipe($nodes) {
        if (isset($this->matrix) && isset($nodes)) {
            $this->graph = new Graph();
            $nodes_for_recipe = array(); //These are the nodes for the recipe
            foreach ($this->matrix as $id) {
                $nodes_for_recipe[] = $nodes[$id];
            }
            $this->graph->set_nodes($nodes_for_recipe); //Set the nodes in the graph
            //This will set the edges of the graph
            //So, the recipe will the be array of edges in the graph
            $this->construct_recipe(true);
        }
    }

    /* It finds out the name, quantity and unit for the ingredients */
    /* An example would be:
     * rice 2 kg
     * water 2 litres
     */

    public function find_noun_quantity_unit() {
        $nodes = $this->graph->get_nodes();
        $this->noun_quantity_unit = array(); //This is the array of nodes
        $noun_list = array(); //This is the list of nouns which are already in use
        foreach ($nodes as $node) {
            $noun = $node->get_noun();
            $keys = array_search($noun, $noun_list);
            if (empty($keys)) {//If the noun has not been used already
                array_push($noun_list, $noun);
                array_push($this->noun_quantity_unit, $node);
            }
        }
    }

    //////////END OF UTILITIES//////////
    //
    //
    //////////SETTERS AND GETTERS//////////

    public function set_common_weight($common_weight) {
        $this->common_weight = $common_weight;
    }

    public function get_common_weight() {
        return $this->common_weight;
    }

    public function set_graph($graph) {
        $this->graph = $graph;
    }

    public function get_graph() {
        return $this->graph;
    }

    public function set_matrix($matrix) {
        $this->matrix = $matrix;
    }

    public function get_matrix() {
        return $this->matrix;
    }

    public function set_noun_quantity_unit($noun_quantity_unit) {
        $this->noun_quantity_unit = $noun_quantity_unit;
    }

    public function get_noun_quantity_unit() {
        return $this->noun_quantity_unit;
    }

    //////////END OF SETTERS AND GETTERS//////////
}

?>
