<?php

/*
 * It represents a directed edge from one node to another node having
 * certain weight.
 */

class Edge extends CI_Model {

    var $from;
    var $to, $weight;
    protected $table = 'edge';
    protected $old_weight;

    function __construct() {
        parent::__construct();
    }

    //////////DATA ACCESS FUNCTIONALITIES//////////
    public function insert() {
        $this->db->insert($this->table, $this);
    }

    public function update() {
        $this->db->query("UPDATE $this->table SET `weight` =$this->weight" . "
            WHERE `from` =" . $this->from . " AND `to` =" . $this->to);
    }

    /* It selects the existing weight in the database for this edge. */

    public function set_old_weight_if_exists() {
        $query = $this->db->get_where($this->table, array(
            'from' => $this->from,
            'to' => $this->to));

        $result = $query->result();
        if (!empty($result)) {
            $this->old_weight = $result[0]->weight;
            return true;
        }
        return false;
    }

    /* Returns an array of edge-like 
     * objects based on the value of "from" in this object. */

    public function select_by_from() {
        $query = $this->db->get_where($this->table, array('from' => $this->from));
        return $query->result();
    }

    /* Returns an array of edge-like objects
     *  based on the value of "to" in this object. */

    public function select_by_to() {
        $query = $this->db->get_where($this->table, array('to' => $this->to));
        return $query->result();
    }

    /* Get all the edges with the fields "from" and "to" in the
     * input array of node ids
     */

    public function select_edges_having_nodes($node_ids) {
        $node_id_str = "(";
        for ($i = 0; $i < count($node_ids); $i++) {
            if ($i == count($node_ids) - 1)
                $node_id_str = $node_id_str . $node_ids[$i] . ')';
            else
                $node_id_str = $node_id_str . $node_ids[$i] . ',';
        }

        $edges = array();
        $query = $this->db->query("SELECT * FROM $this->table WHERE " .
                "`from` in $node_id_str AND `to` in $node_id_str");
        $objects = $query->result();
        if (isset($objects)) {
            foreach ($objects as $object) {
                $edge = $this->object_to_edge($object);
                $edges[] = $edge;
            }
            return $edges;
        }
        return false;
    }

    //////////END OF DATA ACCESS FUNCTIONALITIES//////////
    //////////UTITLITIES//////////
    public function calculate_new_weight() {
        $this->weight +=$this->old_weight;
    }

    public function object_to_edge($object) {
        if (isset($object)) {
            $edge = new Edge();
            if (isset($object->from)) {
                $edge->set_from($object->from);
            }
            if (isset($object->to)) {
                $edge->set_to($object->to);
            }
            if (isset($object->weight)) {
                $edge->set_weight($object->weight);
            }
            return $edge;
        }
        return false;
    }

    //////////END OF UTILITIES//////////
    //////////SETTERS AND GETTERS//////////
    public function set_from($from) {
        $this->from = $from;
    }

    public function get_from() {
        return $this->from;
    }

    public function set_to($to) {
        $this->to = $to;
    }

    public function get_to() {
        return $this->to;
    }

    public function set_weight($weight) {
        $this->weight = $weight;
    }

    public function get_weight() {
        return $this->weight;
    }

    public function set_old_weight($old_weight) {
        $this->old_weight = $old_weight;
    }

    public function get_old_weight() {
        return $this->old_weight;
    }

    public function set_values($from, $to, $weight) {
        $this->from = $from;
        $this->to = $to;
        $this->weight = $weight;
    }

    //////////END OF SETTERS AND GETTER//////////
}

?>
