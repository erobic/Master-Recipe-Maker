<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Unit extends CI_Model {

    protected $units;
    protected $table = 'unit';

    function __construct() {
        parent::__construct();
    }

    public function select_units() {
        $query = $this->db->get($this->table);
        $objects = $query->result();
        foreach ($objects as $object) {
            $this->units[] = $object->unit;
            
        }
        return $this->units;
    }

}

?>
