<?php if (empty($recipe)) { ?>
    <h2>Sorry, I could not generate any recipe using that list of ingredients.</h2>
    <?php
} else {
    ?>
    <h2>Ingredient List</h2>

    <table>
        <tr>
            <th>Ingredient</th>
            <th>Quantity</th>
            <th>Unit</th>
        </tr>
        <tr>
            <?php
            /*
             * To change this te
              mplate, choose Tools | Templates
             * and open the template in the editor.
             */

            if (isset($list)) {
                foreach ($list as $n) {
                    $q = $n->get_quantity();
                    if (isset($q)) {
                        if ($q> 0)
                            $rounded_quantity = round($q, 0);
                    }
                    else
                        $rounded_quantity = "NOT SPECIFIED";
                    ?>

                <tr>
                    <td><?php echo $n->get_noun(); ?></td>
                    <td><?php echo $rounded_quantity; ?></td>
                    <td><?php echo $n->get_unit(); ?></td>
                </tr>
                <?php
            }//foreach
        }//if 
        ?>
    </table>

    <h2>Here is your recipe</h2>



    <?php
    $rowId = 0;
    echo form_open('train/initiate_training');
    ?> 
    <table width="100%">
        <tr>
            <th>Number</th>   
            <th>Steps</th>
        </tr>
        <?php
        foreach ($recipe as $step) {
            ?>

            <tr>
                <td><?php echo $rowId + 1; ?></td>
                <td>
                    <?php
                    echo form_input(array(
                        'name' => 'method' . $rowId,
                        'hidden' => 'true',
                        'value' => $step->get_method()
                    ));

                    echo form_input(array(
                        'name' => 'noun' . $rowId,
                        'hidden' => 'true',
                        'value' => $step->get_noun()
                    ));



                    echo form_input(array(
                        'name' => 'quantity' . $rowId,
                        'hidden' => 'true',
                        'value' => $step->get_quantity()
                    ));

                    echo form_input(array(
                        'name' => 'unit' . $rowId,
                        'hidden' => 'true',
                        'value' => $step->get_unit()
                    ));


                    echo $step->get_method() . ' ' . $step->get_noun();
                    ?>


                </td>
                <?php $rowId++; ?>
            </tr>
        <?php } ?>


        <tr>
            <th>YOUR FEEDBACK</th>
            <th>
                <?php echo form_dropdown('common_weight', $feedback_options, '30'); ?>
                <?php
                echo form_input(array(
                    'name' => 'no_of_steps',
                    'value' => $rowId,
                    'hidden' => 'true'
                ));
                ?>
            </th>
        </tr>

        <tr>
            <th colspan="2"><?php echo form_submit(array('value' => 'SEND THE FEEDBACK')); ?></th>
        </tr>
    </table>
    <?php
}?>