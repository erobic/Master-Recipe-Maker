<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
echo form_open('generate/create_recipe');
?>
<table>
    <tr>
        <th>
            ENTER THE INGREDIENTS YOU WANT TO COOK WITH (SEPARATE EACH INGREDIENT WITH COMMA)
        </th>
    </tr>
    <tr>
        <td><?php echo form_textarea(array("name"=>"noun_list")); ?></td>
    </tr>

    <tr>
        <th colspan ="2"><?php echo form_submit(array("value" => "GENERATE RECIPE!")); ?></th>
    </tr>
</table>
