<?php
$rowId = 0;
echo form_open('train/initiate_training'); //call the train controller
?>
<table width="100%">
    <tr>
        <th>Step</th>   
        <th>Method*</th>
        <th>Ingredient*</th>
        <th>Quantity</th>
        <th>Unit</th>
    </tr>

    <?php
    while ($rowId < 30) {
        ?>
        <tr>
            <td><?php echo $rowId+1; ?></td>
            <td><?php echo form_input(array('name' => 'method' . $rowId)); ?></td>
            <td><?php echo form_input(array('name' => 'noun' . $rowId)); ?></td>
            <td><?php echo form_input(array('name' => 'quantity' . $rowId)); ?></td>    
            <td>
                <?php
                if (isset($units)) {
                    $selected = 'none';
                    echo form_dropdown('unit' . $rowId, $units, $selected);
                }
                ?>
            </td>
            <?php
            $rowId++;
        }
        ?>
    </tr>

    <tr>
        <th>RATING</th>
        <th> <?php echo form_input(array('name' => 'common_weight', 'value' => 10)); ?>
            <?php echo form_input(array('name' => 'no_of_steps', 'value' => '30', 'hidden' => 'tru')); ?>
        </th>
        <th colspan="4"></th> 
    </tr>
    <tr>
        <th colspan="5"><?php echo form_submit(array('value' => 'TRAIN THE MASTER RECIPE MAKER')); ?></th>
    </tr>
</table>


