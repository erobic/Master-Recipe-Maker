<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <title><?php print $title; ?></title>
        <?php print $_scripts; ?>
        <?php print $_styles; ?>
        <link rel="stylesheet" type="text/css" 
              href="<?php echo base_url() . 'css/style.css'; ?>"/>
    </head>
    <body>

        <div id="header">
            <img src="<?php echo base_url(); ?>images/header.jpeg"/>
        </div>

        <div id="content">
            <a href="<?php echo base_url(); ?>index.php/train">TRAIN</a>
            <a href="<?php echo base_url(); ?>index.php/generate">GENERATE</a>
        </div>

        <div id="content">
            <?php print $content; ?>
        </div>

        <div id="footer">
            <?php print $footer; ?>
        </div>

    </body>
</html>