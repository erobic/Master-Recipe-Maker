<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/*
  |--------------------------------------------------------------------------
  | Active template
  |--------------------------------------------------------------------------
  |
  | The $template['active_template'] setting lets you choose which template
  | group to make active.  By default there is only one group (the
  | "default" group).
  |
 */
$template['active_template'] = 'default';
$template['active_group'] = 'default';
$template['default']['template'] = 'template.php';

/*
  |--------------------------------------------------------------------------
  | Explaination of template group variables
  |--------------------------------------------------------------------------
  |
  | ['template'] The filename of your master template file in the Views folder.
  |   Typically this file will contain a full XHTML skeleton that outputs your
  |   full template or region per region. Include the file extension if other
  |   than ".php"
  | ['regions'] Places within the template where your content may land.
  |   You may also include default markup, wrappers and attributes here
  |   (though not recommended). Region keys must be translatable into variables
  |   (no spaces or dashes, etc)
  | ['parser'] The parser class/library to use for the parse_view() method
  |   NOTE: See http://codeigniter.com/forums/viewthread/60050/P0/ for a good
  |   Smarty Parser that works perfectly with Template
  | ['parse_template'] FALSE (default) to treat master template as a View. TRUE
  |   to user parser (see above) on the master template
  |
  | Region information can be extended by setting the following variables:
  | ['content'] Must be an array! Use to set default region content
  | ['name'] A string to identify the region beyond what it is defined by its key.
  | ['wrapper'] An HTML element to wrap the region contents in. (We
  |   recommend doing this in your template file.)
  | ['attributes'] Multidimensional array defining HTML attributes of the
  |   wrapper. (We recommend doing this in your template file.)
  |
  | Example:
 */

/*
  $template['default']['regions'] = array(
  'header' => array(
  'content' => array('<h1>Master Recipe Maker</h1>', ''),
  'name' => 'Your Recipes',
  'wrapper' => '<div>',
  'attributes' => array('id' => 'header', 'class' => 'clearfix')
  ),
  'navBar',
  'content',
  'footer'=>array(
  'content' =>array('<h5>Developed By Robik Shrestha</h5>'),
  'name'=>'footer',
  'wrapper'=>'<div>',
  )
  ); */



/*
  |--------------------------------------------------------------------------
  | Default Template Configuration (adjust this or create your own)
  |--------------------------------------------------------------------------
 */

/* $template['default']['template'] = 'template';
  $template['default']['regions'] = array(
  'header',
  'content',
  'footer',
  ); */

/* I have defined the regions:
 * title
 * header
 * nav_bar
 * content
 * and footer
 */
$template['default']['regions']['title'] = array('Master Recipe Maker');
$template['default']['regions']['header'] = array(
    'content' => array('<h1>Master Recipe Maker</h1>')
);
$template['default']['regions']['nav_bar'] = array();
$template['default']['regions']['content'] = array();
$template['default']['regions']['footer'] = array(
    'content'=>array("<h4>Developed By Robik Shrestha</h4>"));

$template['default']['parser'] = 'parser';
$template['default']['parser_method'] = 'parse';
$template['default']['parse_template'] = FALSE;

/* End of file template.php */
/* Location: ./system/application/config/template.php */