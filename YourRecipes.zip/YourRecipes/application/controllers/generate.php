<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
define('I', 1000);

class Generate extends CI_Controller {

    function __construct() {
        parent::__construct();
    }

    public function index() {
        $this->load->helper('form');
        $this->load->helper('url');
        $this->template->write_view('content', 'generate/form', '', false);
        $this->template->render();
    }

    public function create_recipe() {
        $this->load->model('recipe');
        $this->load->model('graph');
        $this->load->model('dijkstra');
        if (isset($_POST["noun_list"])) {
            $noun_list = $_POST["noun_list"];
            $graph = new Graph();
            $graph->set_nodes_from_nouns($noun_list); //Find out all the nodes
            $graph->set_ids_by_nouns(); //Find out all the nodes with the nouns
            $graph->remove_nodes_with_null_ids();
            $graph->store_start_finish_nodes();
            $graph->find_edges_from_nodes();
            $graph->find_node_ids();
            $graph->graph_to_matrix();
            $matrix = $graph->get_matrix();
            $width_matrix = $graph->get_width_matrix();

            $dijkstra = new Dijkstra();
            $dijkstra->setValues($matrix, 10000, $width_matrix);
            $dijkstra->findShortestPath(0);
            $solution = $dijkstra->getResults($width_matrix - 1);

            $node_ids = $graph->get_node_ids();
            $nodes = $graph->get_nodes();


            $recipe = new Recipe();
            $recipe->set_matrix($solution);
            $recipe->matrix_to_recipe($nodes);
            $recipe->find_noun_quantity_unit(); //This is used to find out the ingredient list
            //without repeating the names of the ingredients



            $noun_quantity_unit = $recipe->get_noun_quantity_unit();

            $final_nodes = $recipe->get_graph()->get_nodes();

            foreach ($noun_quantity_unit as $i => $nqu) {
                if ($nqu->get_id() == 1 || $nqu->get_id() == 2) {
                    unset($noun_quantity_unit[$i]);
                }
            }

            foreach ($final_nodes as $i => $fn) {
                if ($fn->get_id() == 1 || $fn->get_id() == 2) {
                    unset($final_nodes[$i]);
                }
            }

            $feedback_options = array(
                '20' => 'Your are a genius! What a recipe man!!',
                '10' => 'Very good recipe!',
                '0' => 'It was an average recipe.'
            );

            $data = array(
                'list' => $noun_quantity_unit,
                'recipe' => $final_nodes,
                'feedback_options' => $feedback_options
            );

            $this->load->helper('form');
            $this->load->helper('url');
            $this->template->write_view('content', 'generate/recipe', $data, false);
            $this->template->render();

            /* foreach ($solution as $id) {
              $node = $nodes[$id];
              echo 'id ' . $id;
              echo 'method ' . $node->get_method() . ' ' . $node->get_noun() . '<br/>';
              }
              //print_r($solution);
              echo '</pre>'; */
        }
    }

    public function sample_dijkstra() {


// I is the infinite distance.

        $this->load->model('dijkstra');
        echo 'hi';


// Size of the matrix
        $matrixWidth = 7;

// $points is an array in the following format: (router1,router2,distance-between-them)
        /* $points = array(
          array(0, 1, 2),
          array(0, 2, 1),
          array(1, 2, 4),
          array(1, 3, 3),
          array(3, 2, 5)
          ); */

        $points = array(
            array(0, 1, 10),
            array(0, 5, 2),
            array(1, 2, 1),
            array(2, 3, 1),
            array(3, 4, 1),
            array(5, 6, 2),
            array(6, 4, 1)
        );


        $ourMap = array();


// Read in the points and push them into the map

        for ($i = 0, $m = count($points); $i < $m; $i++) {
            $x = $points[$i][0];
            $y = $points[$i][1];
            $c = $points[$i][2];
            $ourMap[$x][$y] = $c;
        }

// ensure that the distance from a node to itself is always zero
// Purists may want to edit this bit out.

        for ($i = 0; $i < $matrixWidth; $i++) {
            for ($k = 0; $k < $matrixWidth; $k++) {
                if ($i == $k)
                    $ourMap[$i][$k] = 0;
            }
        }


// initialize the algorithm class
        $dijkstra = new Dijkstra();
        $dijkstra->setValues($ourMap, I, $matrixWidth);

// $dijkstra->findShortestPath(0,13); to find only path from field 0 to field 13...
        $dijkstra->findShortestPath(0);

// Display the results

        echo '<pre>';
        //echo "the map looks like:\n\n";
        //echo $dijkstra->printMap($ourMap);
        echo "\n\nthe shortest paths from point 0:\n";
        $solution = $dijkstra->getResults(4);
        print_r($solution);
        echo '</pre>';
    }

    /*
      public function sample_recipe() {
      $this->load->model('node');
      $this->load->model('recipe');
      $this->load->model('edge');

      $edges = array();
      $edges[0] = new Edge();
      $edges[0]->set_values(1, 3, 10);
      $edges[1] = new Edge();
      $edges[1]->set_values(3, 5, 20);
      $edges[2] = new Edge();
      $edges[2]->set_values(5, 2, 20);

      $recipe = new Recipe();
      $recipe->set_edges($edges);
      $recipe->find_nodes_from_edges();
      print_r("<pre>");
      print_r($recipe->get_nodes());
      print_r("</pre>");
      }
     */

    /*
      public function select_by_name() {
      $this->load->model('node');
      $this->load->model('recipe');
      $node = new Node();
      $node->set_noun('rock');
      $nodes = array($node);
      print_r("<pre>");
      print_r($nodes);
      print_r("</pre>");
      $recipe = new Recipe();
      $recipe->set_nodes($nodes);
      $recipe->set_ids_by_nouns();
      print_r("<pre>");
      print_r($recipe->get_nodes());
      print_r("</pre>");
      }
     */
}

?>
