<?php

/*
 * Train_controller is used to train the program with recipes.
 * It displays a view which allows the user to specify a recipe.
 * It takes in the list of recipes from its view.
 * It uses the models to insert and update the necessary nodes and edges.
 * 
 */

class Train extends CI_Controller {
    /* The index should display the form to train */

    public function __construct() {
        parent::__construct();
    }

    public function index() {
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->model('unit');
        $unit_object = new Unit();
        $units = $unit_object->select_units();
        $to_send = array();
        foreach ($units as $unit) {
            $to_send = array_merge($to_send, array($unit => $unit));
        }
        $data = array('units' => $to_send);
        $this->template->write_view('content', 'train/form', $data, false);
        $this->template->render();
//$form = array('content' => $this->load->view('train/form', $data,true));
        //$this->load->view('template', $form);
    }

    /* This function should first of all read all the nodes supplied by the user.
     * Then it should determine if eac node exists in the database.
     * If it does, then it should retrieve its id and old parameters. Then, it should update
     * the database with new parameters.
     * Otherwise, it should insert the node.
     */

    public function initiate_training() {

        $this->load->model('node');
        $this->load->model('edge');
        $this->load->model('graph');
        $this->load->model('recipe');

        $nodes = array(); //array of nodes to be inserted or updated

        if (isset($_POST['no_of_steps']))
            $no_of_steps = $_POST['no_of_steps'];
        else
            $no_of_steps = 30;

        for ($i = 0; $i < $no_of_steps; $i++) {
            if (isset($_POST['method' . $i]) && isset($_POST['noun' . $i])) {
                if (!empty($_POST['method' . $i]) && !empty($_POST['noun' . $i])) {
                    $node = new Node();
                    $node->set_method($_POST['method' . $i]);
                    $node->set_noun($_POST['noun' . $i]);
                    if (isset($_POST['quantity' . $i])) {
                        $node->set_quantity($_POST['quantity' . $i]);
                    }

                    if (isset($_POST['unit' . $i])) {
                        $node->set_unit($_POST['unit' . $i]);
                    }
                    $nodes[] = $node;
                }
            }
        }

        $common_weight = 10;
        if (isset($_POST["common_weight"]))
            $common_weight = $_POST["common_weight"];

        $graph = new Graph();
        $graph->set_nodes($nodes);

        $recipe = new Recipe();
        $recipe->set_graph($graph);
        $recipe->set_common_weight($common_weight);
        $recipe->store_recipe();


        $this->index();
    }

    //////////SAMPLE FUNCTIONS//////////

    public function sample_graph() {
        $this->load->model('node');
        $this->load->model('edge');
        $this->load->model('graph');
        $nodes = array();
        $nodes[0] = new Node();
        $nodes[0]->set_id(10);
        $nodes[1] = new Node();
        $nodes[1]->set_id(20);
        $nodes[2] = new Node();
        $nodes[2]->set_id(30);
        $nodes[3] = new Node();
        $nodes[3]->set_id(40);

        $key_id = array();
        foreach ($nodes as $node) {
            $key_id[] = $node->get_id();
        }

        $edges = array();
        $edges[0] = new Edge();
        $edges[0]->set_values(10, 20, 2);

        $edges[1] = new Edge();
        $edges[1]->set_values(10, 30, 1);

        $edges[2] = new Edge();
        $edges[2]->set_values(20, 30, 4);

        $edges[3] = new Edge();
        $edges[3]->set_values(20, 40, 3);

        $edges[4] = new Edge();
        $edges[4]->set_values(40, 30, 5);

        $graph = new Graph();
        $graph->set_nodes($key_id);
        $graph->set_edges($edges);

        $graph->graph_to_matrix();
        print_r("<pre>");
        print_r($graph->get_matrix());
        print_r("</pre>");
        print_r("width = " . $graph->get_width_matrix());
    }

    //////////END OF SAMPLE FUNCTIONS//////////
}

?>
